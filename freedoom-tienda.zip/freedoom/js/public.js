const data = fdLoad();
const state = {
  filter: "Todo",
  cart: JSON.parse(localStorage.getItem("freedoom_cart") || "[]"),
  promoCode: localStorage.getItem("freedoom_promo") || "",
  productId: null,
  size: null
};

function saveCart() {
  localStorage.setItem("freedoom_cart", JSON.stringify(state.cart));
  localStorage.setItem("freedoom_promo", state.promoCode || "");
}

function activePromo() {
  return fdFindPromo(data, state.promoCode);
}

function cartCount() {
  return state.cart.reduce((n, item) => n + item.qty, 0);
}

function cartSubtotal() {
  return state.cart.reduce((n, item) => {
    const product = data.products.find((p) => p.id === item.productId);
    if (!product) return n;
    return n + fdPrice(product, activePromo()) * item.qty;
  }, 0);
}

function renderBanner() {
  const el = document.querySelector("#banner");
  if (data.banner && data.banner.active && data.banner.text) {
    el.textContent = data.banner.text;
    el.classList.remove("hidden");
  } else el.classList.add("hidden");
}

function renderBrand() {
  document.querySelectorAll("[data-brand]").forEach((el) => { el.textContent = data.settings.brand; });
  document.querySelectorAll("[data-tagline]").forEach((el) => { el.textContent = data.settings.tagline; });
  document.querySelector("#about-text").textContent = data.settings.about;
  document.querySelector("#store-address").textContent = data.settings.address || "Perito Moreno, Santa Cruz";
  document.querySelector("#store-hours").textContent = data.settings.hours || "A confirmar";
  document.querySelector("#store-contact").textContent = contactLine();
  document.title = data.settings.brand + " · Streetwear";
}

function contactLine() {
  const bits = [];
  if (data.settings.whatsapp) bits.push("WhatsApp " + data.settings.whatsapp);
  if (data.settings.instagram) bits.push("Instagram " + data.settings.instagram);
  if (data.settings.email) bits.push(data.settings.email);
  return bits.join(" · ") || "Contacto a completar desde el panel";
}

function categories() {
  const set = new Set(data.products.filter((p) => p.active).map((p) => p.category).filter(Boolean));
  return ["Todo", ...set];
}

function renderFilters() {
  const wrap = document.querySelector("#filters");
  wrap.innerHTML = categories().map((cat) => {
    return `<button class="chip ${cat === state.filter ? "active" : ""}" data-cat="${cat}">${cat}</button>`;
  }).join("");
  wrap.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.filter = btn.dataset.cat;
      renderFilters();
      renderGrid();
    });
  });
}

function productCard(product) {
  const promo = activePromo();
  const price = fdPrice(product, promo);
  const stock = fdStock(product);
  const sale = (product.compareAt && product.compareAt > product.price) || (promo && price < product.price);
  const old = product.compareAt > product.price ? product.compareAt : (promo && price < product.price ? product.price : 0);
  return `
    <article class="card">
      <div class="card-photo" style="background-image:url('${product.image}')">
        ${sale ? '<span class="badge">Promo</span>' : ""}
        ${stock <= 0 ? '<span class="badge">Agotado</span>' : ""}
      </div>
      <div class="card-body">
        <div class="muted">${product.category}</div>
        <h3>${product.name}</h3>
        <div class="price">${fdMoney(price)} ${old ? `<s>${fdMoney(old)}</s>` : ""}</div>
        <div class="muted">${stock > 0 ? stock + " en stock" : "Sin stock"}</div>
        <button class="btn full" data-open="${product.id}" ${stock <= 0 ? "disabled" : ""}>Ver prenda</button>
      </div>
    </article>`;
}

function renderGrid() {
  const list = data.products.filter((p) => p.active && (state.filter === "Todo" || p.category === state.filter));
  const grid = document.querySelector("#grid");
  grid.innerHTML = list.length ? list.map(productCard).join("") : `<p class="muted">No hay prendas en esta categoría.</p>`;
  grid.querySelectorAll("[data-open]").forEach((btn) => btn.addEventListener("click", () => openProduct(btn.dataset.open)));
  document.querySelector("#count-label").textContent = list.length + (list.length === 1 ? " prenda" : " prendas");
}

function openProduct(id) {
  const product = data.products.find((p) => p.id === id);
  if (!product) return;
  state.productId = id;
  state.size = (product.sizes.find((s) => s.stock > 0) || {}).size || null;
  const promo = activePromo();
  const price = fdPrice(product, promo);
  document.querySelector("#p-shot").style.backgroundImage = `url('${product.image}')`;
  document.querySelector("#p-cat").textContent = product.category;
  document.querySelector("#p-name").textContent = product.name;
  document.querySelector("#p-desc").textContent = product.description;
  document.querySelector("#p-price").innerHTML = `${fdMoney(price)} ${product.compareAt > product.price ? `<s>${fdMoney(product.compareAt)}</s>` : ""}`;
  document.querySelector("#p-sizes").innerHTML = product.sizes.map((row) => {
    return `<button class="size ${row.size === state.size ? "on" : ""}" data-size="${row.size}" ${row.stock <= 0 ? "disabled" : ""}>${row.size}${row.stock <= 0 ? " · agotado" : ""}</button>`;
  }).join("");
  document.querySelector("#p-sizes").querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.size = btn.dataset.size;
      openProduct(id);
    });
  });
  document.querySelector("#product-modal").classList.add("open");
  document.querySelector("#product-back").classList.add("open");
}

function closeProduct() {
  document.querySelector("#product-modal").classList.remove("open");
  document.querySelector("#product-back").classList.remove("open");
}

function addCurrent() {
  const product = data.products.find((p) => p.id === state.productId);
  if (!product || !state.size) return;
  const sizeRow = product.sizes.find((s) => s.size === state.size);
  if (!sizeRow || sizeRow.stock <= 0) return;
  const existing = state.cart.find((item) => item.productId === product.id && item.size === state.size);
  const inCart = existing ? existing.qty : 0;
  if (inCart + 1 > sizeRow.stock) {
    alert("No hay más stock de ese talle.");
    return;
  }
  if (existing) existing.qty += 1;
  else state.cart.push({ productId: product.id, size: state.size, qty: 1 });
  saveCart();
  closeProduct();
  renderCart();
  openCart();
}

function renderCart() {
  document.querySelector("#cart-count").textContent = cartCount();
  const box = document.querySelector("#cart-lines");
  if (!state.cart.length) {
    box.innerHTML = `<p class="muted">El carrito está vacío.</p>`;
  } else {
    box.innerHTML = state.cart.map((item, index) => {
      const product = data.products.find((p) => p.id === item.productId);
      if (!product) return "";
      const price = fdPrice(product, activePromo());
      return `
        <div class="line">
          <img src="${product.image}" alt="">
          <div class="grow">
            <strong>${product.name}</strong>
            <div class="muted">Talle ${item.size}</div>
            <div>${fdMoney(price)}</div>
            <div class="qty">
              <button data-minus="${index}">−</button>
              <span>${item.qty}</span>
              <button data-plus="${index}">+</button>
              <button data-remove="${index}">Quitar</button>
            </div>
          </div>
        </div>`;
    }).join("");
  }
  const shipNote = document.querySelector("#cart-sub");
  shipNote.textContent = "Subtotal " + fdMoney(cartSubtotal()) + (activePromo() ? " · código " + activePromo().code : "");
  box.querySelectorAll("[data-minus]").forEach((btn) => btn.addEventListener("click", () => changeQty(Number(btn.dataset.minus), -1)));
  box.querySelectorAll("[data-plus]").forEach((btn) => btn.addEventListener("click", () => changeQty(Number(btn.dataset.plus), 1)));
  box.querySelectorAll("[data-remove]").forEach((btn) => btn.addEventListener("click", () => { state.cart.splice(Number(btn.dataset.remove), 1); saveCart(); renderCart(); }));
  renderShippingOptions();
  renderPayOptions();
}

function changeQty(index, delta) {
  const item = state.cart[index];
  const product = data.products.find((p) => p.id === item.productId);
  const sizeRow = product && product.sizes.find((s) => s.size === item.size);
  const next = item.qty + delta;
  if (next <= 0) state.cart.splice(index, 1);
  else if (sizeRow && next > sizeRow.stock) alert("No hay más stock de ese talle.");
  else item.qty = next;
  saveCart();
  renderCart();
}

function openCart() {
  document.querySelector("#cart").classList.add("open");
  document.querySelector("#cart-back").classList.add("open");
  renderCart();
}
function closeCart() {
  document.querySelector("#cart").classList.remove("open");
  document.querySelector("#cart-back").classList.remove("open");
}

function renderShippingOptions() {
  const wrap = document.querySelector("#ship-options");
  const methods = data.shipping.filter((m) => m.enabled);
  wrap.innerHTML = methods.map((m, i) => `
    <label class="pay-box">
      <input type="radio" name="ship" value="${m.id}" ${i === 0 ? "checked" : ""}>
      <strong>${m.name}</strong> · ${fdMoney(m.price)}
      <div class="muted">${m.detail} · ${m.eta}</div>
    </label>`).join("") || `<p class="muted">No hay métodos de envío activos.</p>`;
  wrap.querySelectorAll("input").forEach((input) => input.addEventListener("change", toggleAddress));
  toggleAddress();
}

function selectedShip() {
  const input = document.querySelector("input[name=ship]:checked");
  if (!input) return null;
  return data.shipping.find((m) => m.id === input.value) || null;
}

function toggleAddress() {
  const ship = selectedShip();
  document.querySelector("#address-fields").classList.toggle("hidden", !(ship && ship.needsAddress));
  const sub = cartSubtotal();
  const total = sub + (ship ? Number(ship.price) || 0 : 0);
  document.querySelector("#cart-total").textContent = "Total " + fdMoney(total);
}

function renderPayOptions() {
  const wrap = document.querySelector("#pay-options");
  const options = [];
  if (data.payments.mpEnabled) options.push({ id: "mp", name: "Mercado Pago / transferencia" });
  if (data.payments.bankEnabled) options.push({ id: "bank", name: "Transferencia bancaria" });
  wrap.innerHTML = options.map((opt, i) => `
    <label class="pay-box"><input type="radio" name="pay" value="${opt.id}" ${i === 0 ? "checked" : ""}> ${opt.name}</label>
  `).join("") || `<p class="warn">Todavía no hay métodos de pago activos. Cargalos en el panel.</p>`;
}

function applyPromo() {
  const code = document.querySelector("#promo-input").value.trim();
  const found = fdFindPromo(data, code);
  if (!found) {
    document.querySelector("#promo-msg").textContent = "Ese código no está activo.";
    return;
  }
  state.promoCode = found.code;
  saveCart();
  document.querySelector("#promo-msg").textContent = found.label || "Código aplicado.";
  renderCart();
  renderGrid();
}

function checkout(event) {
  event.preventDefault();
  if (!state.cart.length) return;
  const ship = selectedShip();
  const pay = (document.querySelector("input[name=pay]:checked") || {}).value;
  if (!ship || !pay) {
    alert("Elegí envío y método de pago.");
    return;
  }
  const form = new FormData(event.target);
  const customer = {
    name: form.get("name").trim(),
    phone: form.get("phone").trim(),
    email: form.get("email").trim(),
    city: form.get("city").trim(),
    address: form.get("address").trim(),
    notes: form.get("notes").trim()
  };
  if (!customer.name || !customer.phone) {
    alert("Nombre y teléfono son obligatorios.");
    return;
  }
  if (ship.needsAddress && (!customer.address || !customer.city)) {
    alert("Para este envío hace falta dirección y localidad.");
    return;
  }
  const latest = fdLoad();
  const items = [];
  for (const item of state.cart) {
    const product = latest.products.find((p) => p.id === item.productId);
    const sizeRow = product && product.sizes.find((s) => s.size === item.size);
    if (!product || !sizeRow || sizeRow.stock < item.qty) {
      alert("Se agotó una prenda del carrito. Revisá el stock.");
      Object.assign(data, latest);
      renderGrid();
      renderCart();
      return;
    }
    sizeRow.stock -= item.qty;
    items.push({
      productId: product.id,
      name: product.name,
      size: item.size,
      qty: item.qty,
      price: fdPrice(product, fdFindPromo(latest, state.promoCode))
    });
  }
  const subtotal = items.reduce((n, item) => n + item.price * item.qty, 0);
  const order = {
    id: fdUid("ord"),
    code: fdOrderCode(),
    createdAt: new Date().toISOString(),
    status: "pendiente_pago",
    customer,
    items,
    shipping: { id: ship.id, name: ship.name, price: Number(ship.price) || 0, eta: ship.eta },
    payment: pay,
    promo: state.promoCode || "",
    subtotal,
    total: subtotal + (Number(ship.price) || 0)
  };
  latest.orders.unshift(order);
  fdSave(latest);
  Object.assign(data, latest);
  state.cart = [];
  saveCart();
  closeCart();
  showThanks(order);
  renderGrid();
}

function showThanks(order) {
  const pay = data.payments;
  let block = "";
  if (order.payment === "mp") {
    block = `
      <p><strong>Mercado Pago</strong></p>
      ${pay.mpAlias ? `<p>Alias: <span class="copy">${pay.mpAlias}</span></p>` : `<p class="warn">Alias de Mercado Pago todavía no cargado.</p>`}
      ${pay.mpName ? `<p>A nombre de: ${pay.mpName}</p>` : ""}
      ${pay.mpLink ? `<p><a class="btn small" href="${pay.mpLink}" target="_blank" rel="noopener">Abrir link de pago</a></p>` : `<p class="warn">Link de pago todavía no cargado.</p>`}
    `;
  } else {
    block = `
      <p><strong>Transferencia bancaria</strong></p>
      ${pay.bankName ? `<p>Banco: ${pay.bankName}</p>` : ""}
      ${pay.holder ? `<p>Titular: ${pay.holder}</p>` : ""}
      ${pay.alias ? `<p>Alias: <span class="copy">${pay.alias}</span></p>` : `<p class="warn">Alias bancario todavía no cargado.</p>`}
      ${pay.cbu ? `<p>CBU: <span class="copy">${pay.cbu}</span></p>` : `<p class="warn">CBU todavía no cargado.</p>`}
      ${pay.cuit ? `<p>CUIT/CUIL: ${pay.cuit}</p>` : ""}
    `;
  }
  document.querySelector("#thanks-body").innerHTML = `
    <p class="ok-note">Pedido ${order.code} reservado.</p>
    <p>Total a transferir: <strong>${fdMoney(order.total)}</strong></p>
    <p class="muted">${order.shipping.name} · ${order.shipping.eta}</p>
    ${block}
    <p>${pay.note || ""}</p>
    <p class="muted">Cuando el local confirme el pago, el estado pasa a pagado desde el panel.</p>
  `;
  document.querySelector("#thanks").classList.add("open");
  document.querySelector("#thanks-back").classList.add("open");
}

function renderShippingInfo() {
  document.querySelector("#ship-info").innerHTML = data.shipping.filter((m) => m.enabled).map((m) => `
    <div>
      <strong>${m.name} · ${fdMoney(m.price)}</strong>
      <span class="muted">${m.detail} ${m.eta}</span>
    </div>`).join("");
}

document.querySelector("#open-cart").addEventListener("click", openCart);
document.querySelector("#close-cart").addEventListener("click", closeCart);
document.querySelector("#cart-back").addEventListener("click", closeCart);
document.querySelector("#close-product").addEventListener("click", closeProduct);
document.querySelector("#product-back").addEventListener("click", closeProduct);
document.querySelector("#add-btn").addEventListener("click", addCurrent);
document.querySelector("#apply-promo").addEventListener("click", applyPromo);
document.querySelector("#checkout").addEventListener("submit", checkout);
document.querySelector("#close-thanks").addEventListener("click", () => {
  document.querySelector("#thanks").classList.remove("open");
  document.querySelector("#thanks-back").classList.remove("open");
});
document.querySelector("#promo-input").value = state.promoCode;

renderBanner();
renderBrand();
renderFilters();
renderGrid();
renderCart();
renderShippingInfo();
