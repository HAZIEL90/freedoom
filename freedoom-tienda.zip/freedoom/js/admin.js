let data = fdLoad();
const sessionKey = "freedoom_admin_ok";

function moneyInput(n) { return Number(n) || 0; }

function loginScreen() {
  document.querySelector("#login").classList.remove("hidden");
  document.querySelector("#app").classList.add("hidden");
}
function appScreen() {
  document.querySelector("#login").classList.add("hidden");
  document.querySelector("#app").classList.remove("hidden");
  renderAll();
}

document.querySelector("#login-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const pass = document.querySelector("#password").value;
  if (pass === data.settings.adminPassword) {
    sessionStorage.setItem(sessionKey, "1");
    appScreen();
  } else document.querySelector("#login-error").textContent = "Clave incorrecta.";
});

if (sessionStorage.getItem(sessionKey) === "1") appScreen();
else loginScreen();

document.querySelectorAll(".navb").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".navb").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".view").forEach((v) => v.classList.add("hidden"));
    document.querySelector("#view-" + btn.dataset.view).classList.remove("hidden");
  });
});

document.querySelector("#logout").addEventListener("click", () => {
  sessionStorage.removeItem(sessionKey);
  loginScreen();
});

function renderAll() {
  renderStats();
  renderProducts();
  renderOrders();
  renderPromos();
  renderShipping();
  renderSettings();
}

function renderStats() {
  const pending = data.orders.filter((o) => o.status === "pendiente_pago").length;
  const paid = data.orders.filter((o) => o.status === "pagado" || o.status === "enviado").length;
  const low = data.products.filter((p) => fdStock(p) > 0 && fdStock(p) <= 3).length;
  const sold = data.orders.filter((o) => o.status !== "cancelado").reduce((n, o) => n + o.total, 0);
  document.querySelector("#stats").innerHTML = `
    <div class="stat"><span class="muted">Pedidos pendientes</span><b>${pending}</b></div>
    <div class="stat"><span class="muted">Pagados o enviados</span><b>${paid}</b></div>
    <div class="stat"><span class="muted">Prendas con poco stock</span><b>${low}</b></div>
    <div class="stat"><span class="muted">Ventas confirmadas</span><b>${fdMoney(sold)}</b></div>`;
}

function renderProducts() {
  const body = document.querySelector("#product-rows");
  body.innerHTML = data.products.map((p) => `
    <tr>
      <td><img class="thumb" src="${p.image}" alt=""></td>
      <td><strong>${p.name}</strong><div class="muted">${p.category} · ${p.active ? "visible" : "oculto"}</div></td>
      <td>${fdMoney(p.price)}${p.compareAt ? `<div class="muted"><s>${fdMoney(p.compareAt)}</s></div>` : ""}</td>
      <td>${p.sizes.map((s) => s.size + ":" + s.stock).join(" · ")}</td>
      <td class="row-actions">
        <button class="btn-ghost small" data-edit="${p.id}">Editar</button>
        <button class="btn-ghost small" data-hide="${p.id}">${p.active ? "Ocultar" : "Mostrar"}</button>
        <button class="btn-ghost small" data-del="${p.id}">Quitar</button>
      </td>
    </tr>`).join("");
  body.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openProductForm(b.dataset.edit)));
  body.querySelectorAll("[data-hide]").forEach((b) => b.addEventListener("click", () => {
    const p = data.products.find((x) => x.id === b.dataset.hide);
    p.active = !p.active;
    fdSave(data);
    renderAll();
  }));
  body.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => {
    if (!confirm("¿Quitar esta prenda del catálogo?")) return;
    data.products = data.products.filter((x) => x.id !== b.dataset.del);
    fdSave(data);
    renderAll();
  }));
}

function presetOptions(selected) {
  return FD_PRESET_IMAGES.map((img) => `<option value="${img.src}" ${img.src === selected ? "selected" : ""}>${img.label}</option>`).join("");
}

function openProductForm(id) {
  const product = id ? data.products.find((p) => p.id === id) : {
    id: fdUid("p"),
    name: "",
    category: "Remeras",
    description: "",
    price: 0,
    compareAt: 0,
    image: "img/tee.jpg",
    featured: false,
    active: true,
    sizes: [{ size: "M", stock: 1 }]
  };
  document.querySelector("#product-form-wrap").classList.remove("hidden");
  document.querySelector("#pf-title").textContent = id ? "Editar prenda" : "Nueva prenda";
  const form = document.querySelector("#product-form");
  form.dataset.id = product.id;
  form.innerHTML = `
    <div class="two">
      <div class="field"><label>Nombre</label><input name="name" value="${escapeAttr(product.name)}" required></div>
      <div class="field"><label>Categoría</label><input name="category" value="${escapeAttr(product.category)}" required></div>
    </div>
    <div class="field"><label>Descripción</label><textarea name="description">${escapeText(product.description)}</textarea></div>
    <div class="three">
      <div class="field"><label>Precio</label><input name="price" type="number" min="0" value="${product.price}" required></div>
      <div class="field"><label>Precio anterior (promo)</label><input name="compareAt" type="number" min="0" value="${product.compareAt || 0}"></div>
      <div class="field"><label>Foto de catálogo</label><select name="image">${presetOptions(product.image)}<option value="custom" ${product.image.startsWith("data:") || !FD_PRESET_IMAGES.some((i) => i.src === product.image) ? "selected" : ""}>Otra / subida</option></select></div>
    </div>
    <div class="field"><label>O subir una foto (se guarda en este navegador)</label><input name="file" type="file" accept="image/*"></div>
    <div class="field"><label>Link de imagen (opcional)</label><input name="imageUrl" value="${product.image.startsWith("data:") ? "" : escapeAttr(product.image)}"></div>
    <div id="size-editor"></div>
    <button type="button" class="btn-ghost small" id="add-size">Agregar talle</button>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button class="btn" type="submit">Guardar prenda</button>
      <button class="btn-ghost" type="button" id="cancel-product">Cancelar</button>
    </div>`;
  const sizes = product.sizes.map((s) => ({ ...s }));
  const editor = form.querySelector("#size-editor");
  function drawSizes() {
    editor.innerHTML = sizes.map((s, i) => `
      <div class="two">
        <div class="field"><label>Talle</label><input data-size="${i}" value="${escapeAttr(s.size)}"></div>
        <div class="field"><label>Stock</label><input data-stock="${i}" type="number" min="0" value="${s.stock}"></div>
      </div>`).join("");
    editor.querySelectorAll("[data-size]").forEach((input) => input.addEventListener("input", () => { sizes[input.dataset.size].size = input.value; }));
    editor.querySelectorAll("[data-stock]").forEach((input) => input.addEventListener("input", () => { sizes[input.dataset.stock].stock = moneyInput(input.value); }));
  }
  drawSizes();
  form.querySelector("#add-size").addEventListener("click", () => { sizes.push({ size: "L", stock: 0 }); drawSizes(); });
  form.querySelector("#cancel-product").addEventListener("click", () => document.querySelector("#product-form-wrap").classList.add("hidden"));
  form.onsubmit = async (event) => {
    event.preventDefault();
    const fd = new FormData(form);
    let image = fd.get("imageUrl").trim() || fd.get("image");
    if (image === "custom") image = product.image;
    const file = form.querySelector("input[name=file]").files[0];
    if (file) image = await fileToData(file);
    const next = {
      id: form.dataset.id,
      name: fd.get("name").trim(),
      category: fd.get("category").trim(),
      description: fd.get("description").trim(),
      price: moneyInput(fd.get("price")),
      compareAt: moneyInput(fd.get("compareAt")),
      image,
      featured: true,
      active: true,
      sizes: sizes.filter((s) => s.size).map((s) => ({ size: s.size, stock: Number(s.stock) || 0 }))
    };
    const idx = data.products.findIndex((p) => p.id === next.id);
    if (idx >= 0) next.active = data.products[idx].active;
    if (idx >= 0) data.products[idx] = next;
    else data.products.unshift(next);
    fdSave(data);
    document.querySelector("#product-form-wrap").classList.add("hidden");
    renderAll();
  };
}

function fileToData(file) {
  return new Promise((resolve, reject) => {
    if (file.size > 900000) {
      alert("La foto es pesada. Usá una de menos de 900 KB para que el navegador la guarde.");
      reject(new Error("size"));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}

function renderOrders() {
  const body = document.querySelector("#order-rows");
  body.innerHTML = data.orders.length ? data.orders.map((o) => `
    <tr>
      <td><strong>${o.code}</strong><div class="muted">${new Date(o.createdAt).toLocaleString("es-AR")}</div></td>
      <td>${o.customer.name}<div class="muted">${o.customer.phone}<br>${o.customer.city || ""} ${o.customer.address || ""}</div></td>
      <td>${o.items.map((i) => i.qty + "× " + i.name + " (" + i.size + ")").join("<br>")}</td>
      <td>${o.shipping.name}<div class="muted">${o.payment === "mp" ? "Mercado Pago" : "Banco"} · ${fdMoney(o.total)}</div></td>
      <td>${labelStatus(o.status)}</td>
      <td class="row-actions">
        <button class="btn small" data-paid="${o.id}">Pagado</button>
        <button class="btn-ghost small" data-ship="${o.id}">Enviado</button>
        <button class="btn-ghost small" data-ready="${o.id}">Listo para retiro</button>
        <button class="btn-ghost small" data-cancel="${o.id}">Cancelar</button>
      </td>
    </tr>`).join("") : `<tr><td colspan="6" class="muted">Todavía no hay pedidos.</td></tr>`;
  body.querySelectorAll("[data-paid]").forEach((b) => b.addEventListener("click", () => setStatus(b.dataset.paid, "pagado")));
  body.querySelectorAll("[data-ship]").forEach((b) => b.addEventListener("click", () => setStatus(b.dataset.ship, "enviado")));
  body.querySelectorAll("[data-ready]").forEach((b) => b.addEventListener("click", () => setStatus(b.dataset.ready, "listo_retiro")));
  body.querySelectorAll("[data-cancel]").forEach((b) => b.addEventListener("click", () => cancelOrder(b.dataset.cancel)));
}

function labelStatus(status) {
  return {
    pendiente_pago: "Pendiente de pago",
    pagado: "Pagado",
    enviado: "Enviado",
    listo_retiro: "Listo para retiro",
    cancelado: "Cancelado"
  }[status] || status;
}

function setStatus(id, status) {
  const order = data.orders.find((o) => o.id === id);
  if (order) order.status = status;
  fdSave(data);
  renderAll();
}

function cancelOrder(id) {
  const order = data.orders.find((o) => o.id === id);
  if (!order || order.status === "cancelado") return;
  if (!confirm("¿Cancelar y devolver el stock?")) return;
  order.items.forEach((item) => {
    const product = data.products.find((p) => p.id === item.productId);
    const size = product && product.sizes.find((s) => s.size === item.size);
    if (size) size.stock += item.qty;
  });
  order.status = "cancelado";
  fdSave(data);
  renderAll();
}

function renderPromos() {
  document.querySelector("#banner-active").checked = !!data.banner.active;
  document.querySelector("#banner-text").value = data.banner.text || "";
  document.querySelector("#promo-rows").innerHTML = data.promos.map((p) => `
    <tr>
      <td><strong>${p.code}</strong></td>
      <td>${p.type === "percent" ? p.value + "%" : fdMoney(p.value)}</td>
      <td>${p.label || ""}</td>
      <td>${p.active ? "Activa" : "Pausada"}</td>
      <td class="row-actions">
        <button class="btn-ghost small" data-toggle="${p.id}">${p.active ? "Pausar" : "Activar"}</button>
        <button class="btn-ghost small" data-delp="${p.id}">Quitar</button>
      </td>
    </tr>`).join("") || `<tr><td colspan="5" class="muted">No hay códigos.</td></tr>`;
  document.querySelector("#promo-rows").querySelectorAll("[data-toggle]").forEach((b) => b.addEventListener("click", () => {
    const p = data.promos.find((x) => x.id === b.dataset.toggle);
    p.active = !p.active;
    fdSave(data);
    renderAll();
  }));
  document.querySelector("#promo-rows").querySelectorAll("[data-delp]").forEach((b) => b.addEventListener("click", () => {
    data.promos = data.promos.filter((x) => x.id !== b.dataset.delp);
    fdSave(data);
    renderAll();
  }));
}

document.querySelector("#banner-form").addEventListener("submit", (event) => {
  event.preventDefault();
  data.banner.active = document.querySelector("#banner-active").checked;
  data.banner.text = document.querySelector("#banner-text").value.trim();
  fdSave(data);
  alert("Banner actualizado. Recargá la tienda pública para verlo.");
});

document.querySelector("#promo-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const fd = new FormData(event.target);
  data.promos.unshift({
    id: fdUid("promo"),
    code: fd.get("code").trim().toUpperCase(),
    type: fd.get("type"),
    value: moneyInput(fd.get("value")),
    label: fd.get("label").trim(),
    active: true
  });
  fdSave(data);
  event.target.reset();
  renderAll();
});

function renderShipping() {
  document.querySelector("#ship-rows").innerHTML = data.shipping.map((m) => `
    <tr>
      <td><strong>${m.name}</strong><div class="muted">${m.detail}</div></td>
      <td>${fdMoney(m.price)}</td>
      <td>${m.eta}</td>
      <td>${m.needsAddress ? "Pide dirección" : "Retiro"}</td>
      <td>${m.enabled ? "Activo" : "Oculto"}</td>
      <td class="row-actions">
        <button class="btn-ghost small" data-es="${m.id}">Editar</button>
        <button class="btn-ghost small" data-ts="${m.id}">${m.enabled ? "Ocultar" : "Activar"}</button>
        <button class="btn-ghost small" data-ds="${m.id}">Quitar</button>
      </td>
    </tr>`).join("");
  document.querySelector("#ship-rows").querySelectorAll("[data-ts]").forEach((b) => b.addEventListener("click", () => {
    const m = data.shipping.find((x) => x.id === b.dataset.ts);
    m.enabled = !m.enabled;
    fdSave(data);
    renderAll();
  }));
  document.querySelector("#ship-rows").querySelectorAll("[data-ds]").forEach((b) => b.addEventListener("click", () => {
    data.shipping = data.shipping.filter((x) => x.id !== b.dataset.ds);
    fdSave(data);
    renderAll();
  }));
  document.querySelector("#ship-rows").querySelectorAll("[data-es]").forEach((b) => b.addEventListener("click", () => fillShip(b.dataset.es)));
}

function fillShip(id) {
  const m = data.shipping.find((x) => x.id === id);
  const form = document.querySelector("#ship-form");
  form.dataset.id = m.id;
  form.name.value = m.name;
  form.detail.value = m.detail;
  form.price.value = m.price;
  form.eta.value = m.eta;
  form.needsAddress.checked = !!m.needsAddress;
}

document.querySelector("#ship-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.target;
  const payload = {
    id: form.dataset.id || fdUid("ship"),
    name: form.name.value.trim(),
    detail: form.detail.value.trim(),
    price: moneyInput(form.price.value),
    eta: form.eta.value.trim(),
    needsAddress: form.needsAddress.checked,
    enabled: true
  };
  const idx = data.shipping.findIndex((m) => m.id === payload.id);
  if (idx >= 0) {
    payload.enabled = data.shipping[idx].enabled;
    data.shipping[idx] = payload;
  } else data.shipping.push(payload);
  fdSave(data);
  form.reset();
  delete form.dataset.id;
  renderAll();
});

function renderSettings() {
  const s = data.settings;
  const p = data.payments;
  const form = document.querySelector("#settings-form");
  form.brand.value = s.brand;
  form.tagline.value = s.tagline;
  form.about.value = s.about;
  form.address.value = s.address;
  form.hours.value = s.hours;
  form.whatsapp.value = s.whatsapp;
  form.instagram.value = s.instagram;
  form.email.value = s.email;
  form.phone.value = s.phone;
  form.adminPassword.value = s.adminPassword;
  form.mpEnabled.checked = !!p.mpEnabled;
  form.mpAlias.value = p.mpAlias;
  form.mpLink.value = p.mpLink;
  form.mpName.value = p.mpName;
  form.bankEnabled.checked = !!p.bankEnabled;
  form.bankName.value = p.bankName;
  form.accountType.value = p.accountType;
  form.cbu.value = p.cbu;
  form.alias.value = p.alias;
  form.holder.value = p.holder;
  form.cuit.value = p.cuit;
  form.note.value = p.note;
}

document.querySelector("#settings-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const f = event.target;
  data.settings.brand = f.brand.value.trim();
  data.settings.tagline = f.tagline.value.trim();
  data.settings.about = f.about.value.trim();
  data.settings.address = f.address.value.trim();
  data.settings.hours = f.hours.value.trim();
  data.settings.whatsapp = f.whatsapp.value.trim();
  data.settings.instagram = f.instagram.value.trim();
  data.settings.email = f.email.value.trim();
  data.settings.phone = f.phone.value.trim();
  data.settings.adminPassword = f.adminPassword.value.trim() || "freedoom";
  data.payments.mpEnabled = f.mpEnabled.checked;
  data.payments.mpAlias = f.mpAlias.value.trim();
  data.payments.mpLink = f.mpLink.value.trim();
  data.payments.mpName = f.mpName.value.trim();
  data.payments.bankEnabled = f.bankEnabled.checked;
  data.payments.bankName = f.bankName.value.trim();
  data.payments.accountType = f.accountType.value.trim();
  data.payments.cbu = f.cbu.value.trim();
  data.payments.alias = f.alias.value.trim();
  data.payments.holder = f.holder.value.trim();
  data.payments.cuit = f.cuit.value.trim();
  data.payments.note = f.note.value.trim();
  fdSave(data);
  alert("Datos guardados. La tienda pública los usa al recargar.");
});

document.querySelector("#export").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "freedoom-backup.json";
  a.click();
});

document.querySelector("#import").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const text = await file.text();
  data = JSON.parse(text);
  fdSave(data);
  renderAll();
  alert("Catálogo importado.");
});

document.querySelector("#reset").addEventListener("click", () => {
  if (!confirm("Esto vuelve al catálogo de ejemplo y borra pedidos de este navegador.")) return;
  data = fdSeed();
  fdSave(data);
  renderAll();
});

document.querySelector("#new-product").addEventListener("click", () => openProductForm(null));

function escapeAttr(value) {
  return String(value || "").replace(/"/g, """);
}
function escapeText(value) {
  return String(value || "").replace(/</g, "<");
}
