/* Free Doom — datos compartidos entre la tienda y el panel */
const FD_KEY = "freedoom_store_v1";

const FD_PRESET_IMAGES = [
  { id: "hoodie", label: "Hoodie negro", src: "img/hoodie.jpg" },
  { id: "tee", label: "Remera cruda", src: "img/tee.jpg" },
  { id: "cargo", label: "Cargo oliva", src: "img/cargo.jpg" },
  { id: "cap", label: "Gorra negra", src: "img/cap.jpg" },
  { id: "bomber", label: "Campera bomber", src: "img/bomber.jpg" },
  { id: "crew", label: "Buzo crudo", src: "img/crew.jpg" },
  { id: "detail", label: "Textura", src: "img/detail.jpg" },
  { id: "hero", label: "Campaña", src: "img/hero.jpg" }
];

function fdUid(prefix) {
  return prefix + "_" + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
}

function fdMoney(n) {
  const value = Number(n) || 0;
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(value);
}

function fdSeed() {
  return {
    settings: {
      brand: "Free Doom",
      tagline: "Ropa de calle, hecha para moverse.",
      about: "Free Doom es una tienda de streetwear en Perito Moreno, Santa Cruz. Prendas oversized, telas pesadas y cortes de temporada para usar todos los días. Comprá online y retirá en el local, o recibí el pedido en tu casa en cualquier punto del país.",
      address: "Perito Moreno, Santa Cruz, Argentina",
      hours: "Lunes a sábado, 10 a 13 y 16 a 20",
      phone: "",
      whatsapp: "",
      instagram: "",
      email: "",
      adminPassword: "freedoom"
    },
    banner: {
      active: true,
      text: "Drop de temporada · envío a todo el país · retirá gratis en el local de Perito Moreno"
    },
    payments: {
      mpEnabled: true,
      mpAlias: "",
      mpLink: "",
      mpName: "Free Doom",
      bankEnabled: true,
      bankName: "",
      accountType: "Caja de ahorro en pesos",
      cbu: "",
      alias: "",
      holder: "",
      cuit: "",
      note: "El pedido queda reservado 48 horas. Enviá el comprobante por WhatsApp con el número de pedido para que lo preparemos."
    },
    shipping: [
      { id: "pickup", name: "Retiro en el local", detail: "Perito Moreno, Santa Cruz. Te avisamos cuando está listo.", price: 0, eta: "Listo en 24 horas", needsAddress: false, enabled: true },
      { id: "local", name: "Envío en Perito Moreno", detail: "Entrega en el pueblo, coordinada por WhatsApp.", price: 2500, eta: "1 a 2 días hábiles", needsAddress: true, enabled: true },
      { id: "provincia", name: "Envío Santa Cruz", detail: "Correo o transporte a localidades de la provincia.", price: 7500, eta: "3 a 6 días hábiles", needsAddress: true, enabled: true },
      { id: "pais", name: "Envío al resto del país", detail: "Correo Argentino o Andreani, a domicilio o sucursal.", price: 11500, eta: "5 a 10 días hábiles", needsAddress: true, enabled: true }
    ],
    promos: [
      { id: "promo_drop", code: "CALLE10", type: "percent", value: 10, label: "10% off en toda la tienda", active: true }
    ],
    products: [
      {
        id: "p_hoodie",
        name: "Hoodie Night Shift",
        category: "Buzos",
        description: "Hoodie oversized de algodón pesado, capucha profunda, cordones crudos y bolsillo canguro. Corte suelto para usar sobre remera.",
        price: 68900,
        compareAt: 75900,
        image: "img/hoodie.jpg",
        featured: true,
        active: true,
        sizes: [
          { size: "S", stock: 4 },
          { size: "M", stock: 6 },
          { size: "L", stock: 5 },
          { size: "XL", stock: 3 }
        ]
      },
      {
        id: "p_tee",
        name: "Remera Block",
        category: "Remeras",
        description: "Remera heavyweight color crudo, cuello reforzado y manga corta ancha. Base de cualquier outfit de calle.",
        price: 28900,
        compareAt: 0,
        image: "img/tee.jpg",
        featured: true,
        active: true,
        sizes: [
          { size: "S", stock: 8 },
          { size: "M", stock: 10 },
          { size: "L", stock: 7 },
          { size: "XL", stock: 4 }
        ]
      },
      {
        id: "p_cargo",
        name: "Cargo Route",
        category: "Pantalones",
        description: "Cargo relajado color oliva, bolsillos amplios y tela resistente. Calce cómodo para andar todo el día.",
        price: 72900,
        compareAt: 0,
        image: "img/cargo.jpg",
        featured: true,
        active: true,
        sizes: [
          { size: "38", stock: 3 },
          { size: "40", stock: 4 },
          { size: "42", stock: 4 },
          { size: "44", stock: 2 }
        ]
      },
      {
        id: "p_cap",
        name: "Gorra FD",
        category: "Accesorios",
        description: "Gorra de algodón sin estructura, visera curva y calce suave. Un detalle simple que cierra el look.",
        price: 18900,
        compareAt: 22000,
        image: "img/cap.jpg",
        featured: false,
        active: true,
        sizes: [{ size: "Único", stock: 12 }]
      },
      {
        id: "p_bomber",
        name: "Bomber South Wind",
        category: "Camperas",
        description: "Campera bomber de nylon mate, cuello y puños de rib, cierre metálico. Liviana para el viento de la meseta.",
        price: 98900,
        compareAt: 0,
        image: "img/bomber.jpg",
        featured: true,
        active: true,
        sizes: [
          { size: "S", stock: 2 },
          { size: "M", stock: 3 },
          { size: "L", stock: 3 },
          { size: "XL", stock: 2 }
        ]
      },
      {
        id: "p_crew",
        name: "Buzo Perito",
        category: "Buzos",
        description: "Buzo crewneck de felpa pesada, color crudo, puños y cintura de rib. Ideal para el frío de Santa Cruz.",
        price: 62900,
        compareAt: 0,
        image: "img/crew.jpg",
        featured: false,
        active: true,
        sizes: [
          { size: "S", stock: 3 },
          { size: "M", stock: 5 },
          { size: "L", stock: 4 },
          { size: "XL", stock: 2 }
        ]
      }
    ],
    orders: []
  };
}

function fdLoad() {
  try {
    const raw = localStorage.getItem(FD_KEY);
    if (!raw) {
      const seed = fdSeed();
      localStorage.setItem(FD_KEY, JSON.stringify(seed));
      return seed;
    }
    const data = JSON.parse(raw);
    const seed = fdSeed();
    data.settings = Object.assign({}, seed.settings, data.settings || {});
    data.payments = Object.assign({}, seed.payments, data.payments || {});
    data.banner = Object.assign({}, seed.banner, data.banner || {});
    data.shipping = Array.isArray(data.shipping) && data.shipping.length ? data.shipping : seed.shipping;
    data.promos = Array.isArray(data.promos) ? data.promos : [];
    data.products = Array.isArray(data.products) ? data.products : [];
    data.orders = Array.isArray(data.orders) ? data.orders : [];
    return data;
  } catch (err) {
    const seed = fdSeed();
    localStorage.setItem(FD_KEY, JSON.stringify(seed));
    return seed;
  }
}

function fdSave(data) {
  localStorage.setItem(FD_KEY, JSON.stringify(data));
  window.dispatchEvent(new Event("fd-updated"));
}

function fdStock(product) {
  return (product.sizes || []).reduce((sum, row) => sum + (Number(row.stock) || 0), 0);
}

function fdPrice(product, promo) {
  let price = Number(product.price) || 0;
  if (promo && promo.active) {
    if (promo.type === "percent") price = Math.round(price * (1 - Number(promo.value) / 100));
    if (promo.type === "fixed") price = Math.max(0, price - Number(promo.value));
  }
  return price;
}

function fdFindPromo(data, code) {
  if (!code) return null;
  const clean = String(code).trim().toUpperCase();
  return (data.promos || []).find((p) => p.active && String(p.code).toUpperCase() === clean) || null;
}

function fdOrderCode() {
  const n = Math.floor(1000 + Math.random() * 9000);
  return "FD-" + n;
}
